package jmsdemo.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.jms.TextMessage;
import jmsdemo.models.Department;
import jmsdemo.models.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
public class ProducerService {

    @Value("${spring.activemq.topic}")
    String topic;
    @Value("${spring.activemq.queue}")
    String queue;

    @Autowired
    JmsTemplate jmsTemplate;

    public void sendToQueue() {
        Employee employee = new Employee("John", "Doe", 100000l);
        String empl;
        try {
            empl = new ObjectMapper().writeValueAsString(employee);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        jmsTemplate.send(queue, messageCreator -> {
            TextMessage message = messageCreator.createTextMessage();
            message.setText(empl);
            return message;
        });
    }

    public void sendToTopic() {
        Department department = new Department(1,"CS");
        String dept;
        try {
            dept = new ObjectMapper().writeValueAsString(department);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        jmsTemplate.send(topic, messageCreator -> {
            TextMessage message = messageCreator.createTextMessage();
            message.setText(dept);
            message.setStringProperty("sms","true");
            return message;
        });
    }
}
