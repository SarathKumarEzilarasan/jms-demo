package jmsdemo.service;

import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.TextMessage;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class ConsumerService {

    @JmsListener(destination = "myQueue")
    @SendTo("myQueue2")
    public String receiveAndForwardMessageFromQueue(final Message message) throws JMSException {
        String messageData = null;
        System.out.println("Received message " + message);
        if (message instanceof TextMessage) {
            TextMessage textMessage = (TextMessage) message;
            messageData = textMessage.getText();
            System.out.println("messageData:" + messageData);
        }
        return messageData;
    }

    @JmsListener(destination = "myTopic", selector = "sms='true'")
    @SendTo("myTopic2")
    public String receiveAndForwardMessageFromTopic(final Message message) throws JMSException {
        String messageData = null;
        System.out.println("Received message " + message);
        if (message instanceof TextMessage) {
            TextMessage textMessage = (TextMessage) message;
            messageData = textMessage.getText();
            System.out.println("messageData:" + messageData);
        }
        return messageData;
    }

    @JmsListener(destination = "myTopic", selector = "email='true'")
    public void receiveMessageFromTopic(final Message message) throws JMSException {
        String messageData = null;
        System.out.println("Received message " + message);
        if (message instanceof TextMessage) {
            TextMessage textMessage = (TextMessage) message;
            messageData = textMessage.getText();
            System.out.println("messageData in 2nd listener" + messageData);
        }
    }

}
