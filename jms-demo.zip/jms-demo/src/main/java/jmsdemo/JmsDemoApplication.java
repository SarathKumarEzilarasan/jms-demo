package jmsdemo;

import jmsdemo.service.ProducerService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jms.annotation.EnableJms;

@SpringBootApplication
@EnableJms
public class JmsDemoApplication {

    public static void main(String[] args) {
        ConfigurableApplicationContext applicationContext = SpringApplication.run(JmsDemoApplication.class, args);
        ProducerService producerService = applicationContext.getBean(ProducerService.class);
//        producerService.sendToQueue();
        producerService.sendToTopic();
    }

}
